--SMB3 lua script
--Written by adelikat
--Used to identify and measure corner boost savings

while true do

bob = memory.readbyte(0xFD)
gui.text(1,1,bob .. " Camera X");

charlie = memory.readbyte(0x0480)
gui.text(1,9,charlie .. " Screen X");

emu.frameadvance()
end