--SnapCapture lua script
--Written by adelikat
--Used to automatically capture screenshots from a movie in preparation for making an animated GIF
local delay = 2	 --How many frames between snaps, 0 by default
local start = 0  --The frame count that starts the capture
local finish = 0 --The frame count that end the capture
local count = 0  --Current position in capturing
local capture = false --flag for starting/stopping capture

while true do

if (count % delay == 0) then
	count = count + 1;
	gui.text(1,1,"Screenshot " .. string.format('%3d',count))
	gui.savescreenshot()
end

emu.frameadvance()
end