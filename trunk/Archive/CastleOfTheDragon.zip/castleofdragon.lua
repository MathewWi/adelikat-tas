while true do

local function displayer()

mf = movie.framecount()
startframe = 1025
startx = 0
topspeed = 1

time1=memory.readbyte(0x6BC)
time2=memory.readbyte(0x6BB)
realtime=mf-69

time=256*time1+time2

scrxpix = memory.readbyte(0x0F2)
scrxbig = memory.readbyte(0x0F3)

xpix = memory.readbyte(0x301)

xpos = 256*scrxbig + scrxpix + xpix

gui.text(10,10,"X pos: " .. xpos)
gui.text(10,18,"Lag: " .. realtime-time)

end


gui.register(displayer)
   FCEU.frameadvance()
end